#Introduction
This is an app for https://www.dhis2.org/  build with angular and bower. documentation can be found in the docs folder.
